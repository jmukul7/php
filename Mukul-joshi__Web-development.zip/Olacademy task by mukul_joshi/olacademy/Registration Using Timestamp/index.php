<?php
include("config.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    .form{
            width:400px;
            text-align:center;
            font-size:40px;
            border:2px solid blue;
            text-shadow:2px 2px 3px red;
            position: relative;
            left :30%;
            margin:50px;
        }
         
        input[type=email],input[type=text],input[type=password]{
            border:0.4px solid green;
            border-radius:12px;
            box-shadow:1px 2px 1px navyblue;
            height:25px;
            padding:5px;
        }
        input[type=date]
        {
            border:0.4px solid green; 
            border-radius:12px;
            height:25px;
        }
        input[type=submit]
        {
            border-radius:12px;
            width:150px;
            height:30px;
            background-color:#70a1ff;
            color:black;
            margin-bottom:5px
        }
        span{
            text-shadow:2px 2px 3px green;
            color:black;
            font-size:20px;   
        }
        header{
            width: 100%;
            height: 70px;
            color: white;
            text-align: center;
            background-color: black;
            opacity: .8;
            padding: 10px;
            font-size:50px;
        }
                .b{
            background-color: white;
            color: black;
            font-size:50px;
            
        }
    </style>
    
</head>
<body>
<header><div>Olacademy<span class="b">.com</span></div></header>
<div>
    <form action="" method="post" class="form">
    Full-Name : <input type="text" name="username"><br>
    Email : <input type="email" name="email"><br>
    
    Password : <input type="password" name="password"><br>
    D.O.B : <input type="date" name="dob" id=""><br>
    Gender : 
    
    <span>Male <input type="radio" name="gender" value="male"> OR Female <input type="radio" name="gender" value="female">
    <br>
    <input type="submit" name="submit"></span>
    
    
    
    
    
    
    
    </form>

    
    <?php
       date_default_timezone_set("Asia/Kolkata");
       $s1= date("h:i:sa");
       $s2= date("d-m-Y");
       
        if(isset($_POST['submit'])) {
            # code...
             $username=$_POST['username'];
             $email=$_POST['email'];
             $password=$_POST['password'];
             $dob=$_POST['dob'];
             $gender=$_POST['gender'];
             $s1;
             $s2;

            $result = mysqli_query($mysqli,"insert into registration values('','$username','$email','$password','$dob','$gender','$s1 $s2')");


            if($result)
            {
                
                echo "Registartion succesfull";
                header("location:welcome.php?message='success'");
                
            }
            else{
                echo "Registration fail";
            }
            
        }
    ?>
</div>
</body>
</html>