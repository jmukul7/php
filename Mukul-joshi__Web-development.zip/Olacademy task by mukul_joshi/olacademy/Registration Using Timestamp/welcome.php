<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to olacademy</title>
    <style>
     header{
            width: 100%;
            height: 70px;
            color: white;
            text-align: center;
            background-color: black;
            opacity: .8;
            padding: 10px;
            font-size:50px;
        }
                .b{
            background-color: white;
            color: black;
            text-shadow:2px 2px 3px green;
        }
    </style>
</head>
<body>
<header><div>Olacademy<span class="b">.com</span></div></header>
<div>
<font size="7" color="navy"><marquee>Welcome to Olacademy.com</marquee></font>
<font size="5" color="green"><marquee direction="right">made by mukul__7</marquee></font>
</div>
    
</body>
</html>