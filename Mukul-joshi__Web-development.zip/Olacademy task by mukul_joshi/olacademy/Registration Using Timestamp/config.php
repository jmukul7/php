<?php
$host ="localhost";
$dbusername="root";
$dbpassword="";
$dbname="olacademy";

$mysqli = mysqli_connect($host,$dbusername,$dbpassword,$dbname);

?>