<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        .form{
            width:400px;
            text-align:center;
            font-size:40px;
            border:2px solid blue;
            text-shadow:2px 2px 3px red;
            position: relative;
            left :30%;
            margin:50px;
        }
         
        input[type=email],input[type=text]{
            border:0.4px solid green;
            border-radius:12px;
            box-shadow:1px 2px 1px navyblue;
            height:25px;
            padding:5px;
        }
        textarea{
            border:0.4px solid green;
            border-radius:12px;
            box-shadow:1px 2px 1px navyblue;
            margin:10px
            
        }

        input[type=submit]
        {
            border-radius:12px;
            width:150px;
            height:30px;
            background-color:lightblue;
            color:black;
            margin-bottom:5px
        }
        header{
            width: 100%;
            height: 70px;
            color: white;
            text-align: center;
            background-color: black;
            opacity: .8;
            padding: 10px;
            font-size:50px;
        }
                .b{
            background-color: white;
            color: black;
            text-shadow:2px 2px 3px green;
        }
        </style>
</head>
<body>
    <header><div>Olacademy<span class="b">.com</span></div></header>
    <div class="form">
    <form action="succes.php" method="Post">

    Email : <input type="email" name="email"><br>
    Name : <input type="text" name="username"><br>
    Subject : <input type="text" name="subject"><br>
    Message : <textarea name="message" name="message" ></textarea><br>
    Query : <input type="text" name="query"><br>

    <input type="submit" name="submit">
    
    </form>
    </div>
</body>
</html>