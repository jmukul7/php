<html>
<head>
<title>success</title>
<style>
    .a
    {
        text-align:center;
            font-size:40px;
            border:2px solid blue;
            text-shadow:2px 2px 3px green;
            position: relative;
            left :30%;
            margin:50px;
            color:navyblue;
            width:50%
    }
   
     header{
            width: 100%;
            height: 70px;
            color: white;
            text-align: center;
            background-color: black;
            opacity: .8;
            padding: 10px;
            font-size:50px;
        }
                .b{
            background-color: white;
            color: black;
            text-shadow:2px 2px 3px green;
        }
</style>

</head>
<body>


<header><div>Olacademy<span class="b">.com</span></div></header>
<script>
const a = alert("report successfull");
</script>

<?php
$username = filter_input(INPUT_POST,'username');
$email = filter_input(INPUT_POST,'email');
$subject = filter_input(INPUT_POST,'subject');
$message = filter_input(INPUT_POST,'message');
$query = filter_input(INPUT_POST,'query');

if (!empty($username)) {
    # code...
    if (!empty($email)) {
        # code...
        if (!empty($subject)) {
            # code...
            if (!empty($message)) {
                # code...
                if (!empty($query)) {
                    $host ="localhost";
                    $dbusername="root";
                    $dbpassword="";
                    $dbname="olacademy";
                    $conn = new mysqli ($host,$dbusername,$dbpassword,$dbname);
                    $sql = "INSERT INTO contact (username , email , subject , message , query) value ('$username','$email','$subject','$message','$query')";
                    if($conn -> query($sql)){
                        echo "<script>a</script>";
                    }else{
                        echo "error".$sql."<br>".$conn->error;
                    }
                    $conn->close();
                }
                else
                {
                    echo "enter your query";
                    die();
                
                }
            }
            else
            {
                echo "enter your message";
                die();
            
            }
        }
        else
        {
            echo " enter your subject";
            die();
        
        }
    }
    else
    {
        echo "please enter email first";
        die();
    
    }
}
else
{
    echo "please enter user name first";
    die();

}

?> 
<div class="a">
<?php
    echo "<div>Name : $username </div>";
    echo "<div>Email : $email </div>";
    echo "<div>Subjext : $subject </div>";
    echo "<div>Message :$message </div>";
    echo "<div>Query : $query </div>";
?>
<div><button style="margin-bottom:10px; background-color:lightblue;
            color:black;border-radius:12px;"><a href="index.php" style="text-decoration:none;">Go to Contacct Us</a></button></div>
</div>

</body>
</html>